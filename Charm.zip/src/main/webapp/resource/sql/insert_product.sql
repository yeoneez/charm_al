INSERT INTO product VALUES('P1234', '그로밋 키링', 12000, '귀여운 그로밋을 키링으로 만나보세요','키링', 1000, 'p1234.jpg');
INSERT INTO product VALUES('P1235', '스누피 파우치', 12000, '몽글몽글한 느낌의 스누피 부클 파우치', '파우치', 1000, 'p1235.jpg');
INSERT INTO product VALUES('P1236', '미키마우스 텀블러', 18000, '간편하게 들고 다니는 미키마우스 텀블러', '텀블러', 1000, 'p1236.jpg');

commit;

select * from product;