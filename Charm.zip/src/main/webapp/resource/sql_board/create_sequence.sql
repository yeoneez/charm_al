drop sequence id_seq;

CREATE SEQUENCE num_seq
START WITH 1
INCREMENT BY 1;